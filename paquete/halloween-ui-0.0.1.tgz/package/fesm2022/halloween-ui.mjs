import * as i0 from "@angular/core";
import { Component, EventEmitter, Input, Output } from "@angular/core";
var HalloweenUi = class HalloweenUi {
	constructor() {}
	ngOnInit() {}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.5",
			ngImport: i0,
			type: HalloweenUi,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.5",
			type: HalloweenUi,
			isStandalone: true,
			selector: "lib-halloween-ui",
			ngImport: i0,
			template: "<p>halloween-ui works!</p>\n",
			styles: [""]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: HalloweenUi,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-halloween-ui",
			imports: [],
			template: "<p>halloween-ui works!</p>\n"
		}]
	}],
	ctorParameters: () => []
});
var MonsterCardComponent = class MonsterCardComponent {
	constructor() {
		this.image = "";
		this.title = "";
		this.text = "";
		this.buttonText = "Descubrir";
		this.action = new EventEmitter();
	}
	ejecutarAccion() {
		this.action.emit();
	}
	static {
		this.ɵfac = i0.ɵɵngDeclareFactory({
			minVersion: "12.0.0",
			version: "22.2.5",
			ngImport: i0,
			type: MonsterCardComponent,
			deps: [],
			target: i0.ɵɵFactoryTarget.Component
		});
	}
	static {
		this.ɵcmp = i0.ɵɵngDeclareComponent({
			minVersion: "14.0.0",
			version: "22.2.5",
			type: MonsterCardComponent,
			isStandalone: true,
			selector: "lib-monster-card",
			inputs: {
				image: "image",
				title: "title",
				text: "text",
				buttonText: "buttonText"
			},
			outputs: { action: "action" },
			ngImport: i0,
			template: "<div class=\"monster-card\">\n\n  <img [src]=\"image\" [alt]=\"title\">\n\n  <div class=\"card-content\">\n\n    <h2>{{ title }}</h2>\n\n    <p>{{ text }}</p>\n\n    <button (click)=\"ejecutarAccion()\">\n      {{ buttonText }}\n    </button>\n\n  </div>\n\n</div>",
			styles: [".monster-card{background:#29251f;border:2px solid #B99B69;border-radius:12px;overflow:hidden;box-shadow:0 5px 15px #00000080;transition:transform .3s,box-shadow .3s;margin:20px}.monster-card img{width:100%;height:350px;object-fit:cover;object-position:center top;border-radius:8px}.card-content{padding:15px;text-align:center}.card-content h2{color:#b99b69;font-size:22px;margin-bottom:10px}.card-content p{color:#d8c69d;line-height:1.5}.card-content button{background:#8c392d;color:#fff;border:1px solid #B99B69;border-radius:6px;padding:10px 20px;margin-top:10px;cursor:pointer;transition:background .3s}.card-content button:active{transform:scale(.95)}\n"]
		});
	}
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.5",
	ngImport: i0,
	type: MonsterCardComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "lib-monster-card",
			standalone: true,
			imports: [],
			template: "<div class=\"monster-card\">\n\n  <img [src]=\"image\" [alt]=\"title\">\n\n  <div class=\"card-content\">\n\n    <h2>{{ title }}</h2>\n\n    <p>{{ text }}</p>\n\n    <button (click)=\"ejecutarAccion()\">\n      {{ buttonText }}\n    </button>\n\n  </div>\n\n</div>",
			styles: [".monster-card{background:#29251f;border:2px solid #B99B69;border-radius:12px;overflow:hidden;box-shadow:0 5px 15px #00000080;transition:transform .3s,box-shadow .3s;margin:20px}.monster-card img{width:100%;height:350px;object-fit:cover;object-position:center top;border-radius:8px}.card-content{padding:15px;text-align:center}.card-content h2{color:#b99b69;font-size:22px;margin-bottom:10px}.card-content p{color:#d8c69d;line-height:1.5}.card-content button{background:#8c392d;color:#fff;border:1px solid #B99B69;border-radius:6px;padding:10px 20px;margin-top:10px;cursor:pointer;transition:background .3s}.card-content button:active{transform:scale(.95)}\n"]
		}]
	}],
	propDecorators: {
		image: [{ type: Input }],
		title: [{ type: Input }],
		text: [{ type: Input }],
		buttonText: [{ type: Input }],
		action: [{ type: Output }]
	}
});
export { HalloweenUi, MonsterCardComponent };

//# sourceMappingURL=halloween-ui.mjs.map